class Face {
	
	constructor(hash, age, gender, lastPosition, lastTime, smile, width, height) {

		this.hash 			= hash;
		this.age 			= age;
		this.gender 		= gender;
		this.lastPosition 	= lastPosition;
		this.lastTime 		= lastTime;
		this.smile 			= smile;
		this.width			= width;
		this.height			= height;

	}

}

export default Face;